const BE_CONFIG = {
    SUPABASE_URL: 'https://mtokobzepmfgxfnrrpep.supabase.co',
    SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10b2tvYnplcG1mZ3hmbnJycGVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE1NzA4MjUsImV4cCI6MjA4NzE0NjgyNX0.Exsg7_fhXYruLC2ZMPWr4byU-7OrrcM_hInW0tJ98Gw',
    API_URL: 'http://localhost:3000'
};